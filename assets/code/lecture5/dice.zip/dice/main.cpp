// Dice rolling application - main program


#include <cstdlib>
#include <QApplication>
#include "window.hpp"

int main(int argc, char* argv[])
{
  QApplication app(argc, argv);

  // Seed PRNG with current time

//  qsrand(time(NULL));

  // Create window and make it visible

  DiceRoller* window = new DiceRoller();
  window->show();

  return app.exec();
}
