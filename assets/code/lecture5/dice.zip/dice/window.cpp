// Dice rolling application - class implementation

#include <QtWidgets>
#include "window.hpp"

DiceRoller::DiceRoller()
{
  loadDieFaceImages();
  createWidgets();
  arrangeWidgets();
  setWindowTitle("Dice Roller");
}


void DiceRoller::loadDieFaceImages()
{
  for (int i = 0; i < 6; ++i) {
    QString filename = QString(":/die%1.png").arg(i+1);
    dieFaces[i].load(filename);
  }
}

void DiceRoller::createWidgets()
{
  die1 = new QLabel();
  die2 = new QLabel();
  die1->setPixmap(dieFaces[2]);
  die2->setPixmap(dieFaces[3]);

  rollButton = new QPushButton("Roll Dice");
}

void DiceRoller::arrangeWidgets()
{
  // Arrange dice labels horizontally

  QHBoxLayout* diceLayout = new QHBoxLayout();
  diceLayout->addWidget(die1);
  diceLayout->addWidget(die2);

  // Arrange dice box and button vertically

  QVBoxLayout* layout = new QVBoxLayout();
  layout->addLayout(diceLayout);
  layout->addWidget(rollButton);
  setLayout(layout);
}


