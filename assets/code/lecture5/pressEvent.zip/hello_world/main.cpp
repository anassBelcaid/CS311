#include <QApplication>
#include "specialevent.h"





int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


    SpecialEvent *window = new SpecialEvent();
    window->setWindowTitle("Key Press event");
    window->show();

    return a.exec();
}
