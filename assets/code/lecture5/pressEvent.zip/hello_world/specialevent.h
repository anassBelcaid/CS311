#ifndef SPECIALEVENT_H
#define SPECIALEVENT_H
#include <QWidget>
#include <QtWidgets>


class SpecialEvent : public QWidget
{
public:
    SpecialEvent();
    virtual ~SpecialEvent();
 private:
    void createWidgets();
    void placeWidgets();
    void makeConnexions();

private:
    //members

    QLabel *mainLabel;
    QHBoxLayout *mainLayout;
protected:
    void keyPressEvent(QKeyEvent *e);
};

#endif // SPECIALEVENT_H
