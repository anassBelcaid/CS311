#include "specialevent.h"

SpecialEvent::SpecialEvent():QWidget()
{
    createWidgets();
    placeWidgets();
    makeConnexions();
}

SpecialEvent::~SpecialEvent()
{
    delete mainLabel;
    delete mainLayout;
}

void SpecialEvent::createWidgets()
{
    // Create the label
    mainLabel = new QLabel("K", this);
    mainLabel->setFont(QFont("monospace",50));


    //Create the layout
    mainLayout = new QHBoxLayout();
}

void SpecialEvent::placeWidgets()
{

    mainLayout->addWidget(mainLabel);
    setLayout(mainLayout);
}

void SpecialEvent::makeConnexions()
{

}
void SpecialEvent::keyPressEvent(QKeyEvent *e)
{

}
