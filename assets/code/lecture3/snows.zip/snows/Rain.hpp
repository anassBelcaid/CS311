#pragma once
#include "snow.hpp"


class Rain: public Snow
{
     virtual void method1()
     {
         cout << "Rain 1" << endl;
     }

     virtual void method2()
     {
         cout << "Rain 2" << endl;
     }
};
