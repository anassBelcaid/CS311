#include <iostream>
#include "Fog.hpp"
#include "Rain.hpp"

using namespace std;


int main()
{
  Snow * var4 = new Fog();
  var4->method2();
}
