#pragma once
#include "Sleet.hpp"


class Fog : public Sleet
{
   virtual void method1()
   {
       cout << "Fog 1" << endl;
   }

   virtual void method2()
   {
       cout << "Fog 2 " << endl;
   }

   virtual void method3()
   {
       cout << "Fog 3" << endl;
   }
};
