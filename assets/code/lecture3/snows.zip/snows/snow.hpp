#pragma once
#include <iostream>
using std::cout;
using std::endl;

class Snow
{
    public:
        virtual void method2(){
            cout << "Snow 2" << endl;
        }

        virtual void method3()
        {
            cout << "Snow 3" << endl;
        }
};
