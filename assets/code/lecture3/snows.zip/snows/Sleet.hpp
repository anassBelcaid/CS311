#pragma once
#include "snow.hpp"


class Sleet : public Snow
{
    
    public:
    virtual void method2()
    {
        cout << "Sleet 2" << endl;
    }

     virtual void method3()
    {
        cout << "Sleet 3" << endl;
    }
};
