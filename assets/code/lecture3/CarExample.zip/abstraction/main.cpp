#include <iostream>
#include <string>
#include <vector>
#include "classes.hpp"

using namespace std;


int main(int argc, char *argv[])
{
   //What should we fix in order to instantiate this class
   Car *C = new Mecanical(4);
   cout << *C << endl;


   C->accelerate();

   cout << *C << endl;
  return 0;
}
