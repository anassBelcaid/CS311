#include <iostream>
using std::cout;
using std::endl;
using std::ostream;

#include <string>
using std::string;

class Car
{

    protected:
        int num_wheels;
        int speed;
    public:
    Car(int num_wheels);
    virtual  void accelerate() = 0;
    virtual void Break() = 0;

    friend ostream &operator<<(ostream &, const Car &);
};
 
ostream & operator<<( ostream & out, const Car & C)
{
    out << "Car  [speed] : " <<   C.speed ;
    return out;
}

Car::Car(int num_wheels):num_wheels(num_wheels)
{
  
}


class Mecanical : public Car
{

    using Car::Car;

    void virtual accelerate()override;
    
};

void Mecanical::accelerate()
{

    speed += 2;
}




