#include <iostream>
#include "person.hpp"


using namespace std;


int main()
{
    Person * P1 = new Student("Steve", 321, "Euromed", "CS", 4);
    P1->displayProfile();


    //Down casting
    // Dynamic cast
    Student *P2 = dynamic_cast<Student*>(P1);
    P2->changeMajor("PH");

    P1->displayProfile();

}


