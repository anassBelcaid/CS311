#include <string>
using std::string;

#include <iostream>
using std::cout;
using std::endl;

//Class Person
class Person
{
/* private: */
    public: 
    int id;
    string name;
    string address;

public:
    Person(string , int , string);
    virtual void displayProfile()const;
};


Person::Person(string name, int id, string address):name(name),id(id),address(address)
{
}
void Person::displayProfile()const
{
    cout << string(40, '-') << endl;
    cout << "ID: " << id << " Name: " << name << " " <<  address << endl;
    cout << string(40, '-') << endl;
}



// Class Student
class Student: public Person{
    private:
        int num_courses;
        string major;

    public:
        void changeMajor(string M);
        Student(string name, int id, string address, string major, int num_courses);
        void displayProfile()const override;
};

Student::Student(string name, int id, string address, string major, int num_cours):Person(name, id, address),major(major),num_courses(num_cours)
{
}

void Student::displayProfile()const
{

    cout << string(40, '-') << endl;
    cout << "ID: " << id << " Name: " << name << " " <<  address << endl;
    cout << "Major :" << major << "\t num courses: " << num_courses << endl;
    cout << string(40, '-') << endl;
}

void Student::changeMajor(string M)
{
    major  = M;
}
