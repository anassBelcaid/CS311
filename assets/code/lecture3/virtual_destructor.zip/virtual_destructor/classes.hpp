#include <iostream>
using std::cout;
using std::endl;

#include <fstream>
using std::ifstream;


#include <string>
using std::string;

class Base
{
    protected:
        int * nums;
    public:
        Base(int n);
        ~Base();
};

Base::Base(int n)
{
    nums = new int[n];
}

Base::~Base()
{
    delete [] nums;
}


class Derived : public Base{

private:
    int * nums2;
public:
    Derived(int n, int m);
    ~Derived();
};


Derived::Derived(int n, int m):Base(n)
{
    //opening the file
    nums2 = new int[m];
}


Derived::~Derived()
{
   delete [] nums2;
}


