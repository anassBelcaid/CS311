#include "classes.hpp"


int main()
{
    
    //Creating a derived class using the Base pointer
    Base * var = new Derived(4, 4);



    //calling the destructor
    delete var;

}
