#include <iostream>
#include <string>
#include <vector>

using namespace std;


class A
{
    protected:
        int a;
    public:
        A(int a):a(a){};
};

class B
{
    protected:
        int b;
    public:
        B(int b):b(b){};
};

//Create a class C from A and B
// Your code here

int main(int argc, char *argv[])
{  
    C  var(3, 4);
    cout << var.diff() << endl;
}
