#pragma once
#include "employee.h"

class Lawyer : public Employee{


    //constructor
    public:
    Lawyer(string name, int years, string school);
    Lawyer(string name, int years);

    virtual double salary()const;


    //Inherting all the base constructor
    using Employee::Employee;


    private:
        string school;
};

