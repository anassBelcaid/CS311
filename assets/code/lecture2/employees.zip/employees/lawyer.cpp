#include "lawyer.h"


Lawyer::Lawyer(string name, int years, string school):Employee(name, years)
{

    this->school = school;

}

Lawyer::Lawyer(string name, int years):Employee(name, 0)
{
    ;
}

double Lawyer::salary()const{

    return 8000 + 500 * years();
}


