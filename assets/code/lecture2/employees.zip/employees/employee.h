#pragma once
#include <string>
using std::string;

class Employee{
    public:
        Employee(string name, int years);
        virtual int hours()const;
        virtual string name()const;
        virtual double salary()const;
        virtual int vacationDays()const;
        virtual string vacationForm()const;
        virtual int years()const;

    private:
        string myName;
        int myYears;
};
