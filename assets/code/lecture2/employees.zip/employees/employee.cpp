#include "employee.h"

Employee::Employee(string name, int years){
    myName = name;
    myYears = years;
}


int Employee::hours() const{
    return 40;
}

string Employee::name()const
{
    return myName;
}

double Employee::salary()const
{
    return 40000.0 + 500 * myYears;
}


int Employee::vacationDays()const
{
    return 10;
}

string Employee::vacationForm() const
{
    return "yellow";
}

int Employee::years() const{
    return myYears;
}





