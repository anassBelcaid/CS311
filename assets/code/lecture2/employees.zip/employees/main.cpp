#include <iostream>
#include <string>
#include <vector>
#include "employee.h"
#include "lawyer.h"

using namespace std;


int main(int argc, char *argv[])
{
    /* Lawyer *law1 = new Lawyer("law1", 2, "MIT"); */
    Lawyer *law1 = new Lawyer("Law1", 2);
    cout << law1->salary() << endl;

  return 0;
}
