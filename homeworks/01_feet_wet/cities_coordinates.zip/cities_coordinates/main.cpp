/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include "console.h"
#include "testing/SimpleTest.h"
#include <QtCore>
#include <fstream>

using namespace std;

/*
 * This sample main brings up testing menu.
 */
int main() {

    //Program to load a set of files coordinates and print their information
    // with a simple template






    return 0;
}

