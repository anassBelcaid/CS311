/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include <QtCore>
#include "console.h"
#include "testing/SimpleTest.h"
using namespace std;

int minMoves(QVector<int> & nums)
{
  //Function to receive a Qt Vector and print the minimum
  // moves to make all the elements equal

  // Your code here

}



/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
    cout << "All done, exiting" << endl;
    return 0;
}

PROVIDED_TEST("Test1")
{
    QVector<int> nums{1,2, 3};
    EXPECT_EQUAL(minMoves(nums), 3);
}


PROVIDED_TEST("Test2")
{

    QVector<int> nums{1,1, 1000000000};
    EXPECT_EQUAL(minMoves(nums), 999999999);
}


PROVIDED_TEST("Test3")
{

    QVector<int> nums{5, 6, 8, 8 , 5};

    EXPECT_EQUAL(minMoves(nums), 7);
}



PROVIDED_TEST("Test4")
{

    QVector<int> nums{5, 6, 2, 4, 3};

    EXPECT_EQUAL(minMoves(nums), 10);
}

