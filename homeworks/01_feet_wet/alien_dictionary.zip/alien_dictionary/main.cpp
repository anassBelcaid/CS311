/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include "console.h"
#include "testing/SimpleTest.h"
#include <algorithm>
#include <QtCore>
using vecS = QVector<QString>;
using namespace std;



/*
 * Function to verify if the array of string is sorted
 */
bool isAlienSorted(vecS &words, QString dictionary)
{
    // Function to verfiy if the array of string <words> is
    // sorted accoring to dictionary


}

/*
 * This sample main brings up testing menu.
 */
int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }
    cout << "All done, exiting" << endl;
    return 0;
}

PROVIDED_TEST("Test1")
{
    vecS words{"hello","letscode"};
    QString dict{"hlabcdefgijkmnopqrstuvwxyz"};

    EXPECT_EQUAL(isAlienSorted(words, dict), true);

}


PROVIDED_TEST("Test2")
{
    vecS words{"word","world","row"};
    QString dict{"worldabcefghijkmnpqstuvxyz"};

    EXPECT_EQUAL(isAlienSorted(words, dict), false);

}

PROVIDED_TEST("Test3")
{
    vecS words{"apple","app"};
    QString dict{"abcdefghijklmnopqrstuvwxyz"};

    EXPECT_EQUAL(isAlienSorted(words, dict), false);

}


PROVIDED_TEST("Test4")
{
    vecS words{"apple","apple"};
    QString dict{"abcdefghijklmnopqrstuvwxyz"};


    EXPECT_EQUAL(isAlienSorted(words, dict), true);
}
