/*
 * File: main.cpp
 * --------------
 * Sample QT project
 */

#include <iostream>
#include <gwindow.h>
#include <Artist.h>
#include "ellipse.h"
#include "rectangle.h"
#include "Triangle.h"

using namespace std;

/*
 * This sample main brings up testing menu.
 */

int main() {

    // Creating the default canvas
    GWindow win(500, 500);
    win.setColor("black");
    win.setLineWidth(2);
    //win.drawOval(250, 250, 60, 100);


    //Creating the artist
    Artist painter(win);


    //Adding a shape
    painter.addShape(new Ellipse(250,250, 100, 200));
    painter.addShape(new Rectangle(250,250, 100, 100));
    painter.addShape(new Triangle(250, 250, 50));




    //Drawing the shapes
    painter.drawShapes();
    win.saveCanvasPixels("simple_objects.png");

    // Set the closing operation
    win.setExitOnClose(true);
    return 0;
}
