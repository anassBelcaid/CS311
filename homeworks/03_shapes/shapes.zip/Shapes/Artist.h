#ifndef ARTIST_H
#define ARTIST_H

#include "shapes.h"
#include <vector>
using std::vector;

/*
 * An artist class that print and draw a set of aggregated shapes
 */

class Artist
{
public:

    //Constructor with a Canvas
    Artist (GWindow & wind):wind(wind)
    {
        shapes = vector<Shape*>();
    }

    // Function to add a shape to the set of predifined shapes
    void addShape(Shape * shape)
    {
        shapes.push_back(shape);
    }

    //Draw all the shapes into the canvas
    void drawShapes()
    {

        for(auto shape: shapes)
            shape->draw(wind);
    }

private:
    GWindow & wind;
    vector<Shape*> shapes;

};

#endif // ARTIST_H
