#ifndef SHAPES_H
#define SHAPES_H
#include <gwindow.h>

// Define the abstract class Shape
// to represent all the shapes
class Shape
{
public:
    //default constructor
    // create a shape in (0,0)
    Shape() : pos(0,0){}

    //Create a shape in (x, y)
    Shape(double x, double y): pos(x, y){}

    // Area of the shape (abstract)
    virtual double area() const = 0;


    //Drawing in a window
    virtual void draw(GWindow & canvas) const = 0;

    // modifiers
    void set_position(double x_pos, double y_pos)
    {
        pos.x = x_pos;
        pos.y = y_pos;
    }

    // Accessser
    double get_x_pos() const {return pos.x;}
    double get_y_pos() const {return pos.y;}

private:
        // position of the shape
        GPoint pos;
};

#endif // SHAPES_H
